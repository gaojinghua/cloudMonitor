import Numeric
import numeric_demo

a = Numeric.array([[1.0, 3.5, 8.4], [2.3, 6.6, 4.1]], "f")
numeric_demo.print_2d_array(a)
